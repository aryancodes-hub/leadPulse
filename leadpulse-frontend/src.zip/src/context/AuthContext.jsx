"use client";

import { createContext, useContext, useEffect, useState } from "react";

import {
  login as loginService,
  logout as logoutService,
  refreshToken as refreshTokenService
} from "@/lib/auth";

import { clearAccessToken } from "@/api/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function restoreSession() {
      if (typeof window !== "undefined" && !localStorage.getItem("hasSession")) {
        setIsLoading(false);
        return;
      }

      try {
        const data = await refreshTokenService();

        if (data?.accessToken) {
          const base64Url = data.accessToken.split(".")[1];
          const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
          const decoded = JSON.parse(atob(base64));

          setUser({ id: decoded.id });
          setRole(decoded.role);
          setIsAuthenticated(true);
        } else {
          throw new Error("Invalid token payload");
        }
      } catch (error) {
        console.warn("Session restore failed:", error?.message || error);
        clearAccessToken();
        setUser(null);
        setRole(null);
        setIsAuthenticated(false);
        if (typeof window !== "undefined") {
          localStorage.removeItem("hasSession");
        }
      } finally {
        setIsLoading(false);
      }
    }

    restoreSession();
  }, []);

  async function login(credentials) {
    const data = await loginService(credentials);
    setUser(data?.user ?? null);
    setRole(data?.role ?? data?.user?.role ?? null);
    setIsAuthenticated(true);
    
    if (typeof window !== "undefined") {
      localStorage.setItem("hasSession", "true"); 
    }
    
    return data;
  }

  async function logout() {
    try {
      await logoutService();
    } finally {
      setUser(null);
      setRole(null);
      setIsAuthenticated(false);
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        isAuthenticated,
        isLoading,
        login,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used inside AuthProvider.");
  }

  return context;
}
